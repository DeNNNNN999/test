"use client"

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from "@/components/ui/use-toast"

interface ProgressData {
  date: string;
  value: number;
}

export default function ProgressPage() {
  const [progressData, setProgressData] = useState<ProgressData[]>([]);
  const [metric, setMetric] = useState('');
  const [value, setValue] = useState('');
  const router = useRouter();
  const { toast } = useToast()

  useEffect(() => {
    fetchProgressData();
  }, []);

  const fetchProgressData = async () => {
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/login');
      return;
    }

    try {
      const response = await fetch('http://localhost:3001/api/progress', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (response.ok) {
        const data = await response.json();
        setProgressData(data);
      } else {
        throw new Error('Failed to fetch progress data');
      }
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить данные о прогрессе",
        variant: "destructive",
      })
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/login');
      return;
    }

    try {
      const response = await fetch('http://localhost:3001/api/progress', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ metric, value: parseFloat(value) }),
      });
      const data = await response.json();
      if (response.ok) {
        toast({
          title: "Прогресс добавлен",
          description: "Ваш прогресс успешно добавлен",
        })
        setMetric('');
        setValue('');
        fetchProgressData();
      } else {
        toast({
          title: "Ошибка",
          description: data.message,
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Ошибка",
        description: "Произошла ошибка при добавлении прогресса",
        variant: "destructive",
      })
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen py-2">
      <main className="flex flex-col items-center justify-center w-full flex-1 px-20 text-center">
        <h1 className="text-4xl font-bold mb-6">Отслеживание прогресса</h1>
        <form onSubmit={handleSubmit} className="w-full max-w-xs mb-8">
          <Input
            type="text"
            placeholder="Метрика (например, вес или время бега)"
            value={metric}
            onChange={(e) => setMetric(e.target.value)}
            className="mb-4"
          />
          <Input
            type="number"
            step="0.01"
            placeholder="Значение"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            className="mb-4"
          />
          <Button type="submit" className="w-full">Добавить прогресс</Button>
        </form>
        <div className="w-full max-w-4xl">
          <h2 className="text-2xl font-bold mb-4">График прогресса</h2>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={progressData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="value" stroke="#8884d8" activeDot={{ r: 8 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </main>
    </div>
  );
}
"use client"

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from "@/components/ui/use-toast"

export default function AddWorkout() {
  const [date, setDate] = useState('');
  const [duration, setDuration] = useState('');
  const [notes, setNotes] = useState('');
  const router = useRouter();
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/login');
      return;
    }

    try {
      const response = await fetch('http://localhost:3001/api/workouts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ date, duration: parseInt(duration), notes }),
      });
      const data = await response.json();
      if (response.ok) {
        toast({
          title: "Тренировка добавлена",
          description: "Ваша тренировка успешно добавлена",
        })
        router.push('/dashboard');
      } else {
        toast({
          title: "Ошибка",
          description: data.message,
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Ошибка",
        description: "Произошла ошибка при добавлении тренировки",
        variant: "destructive",
      })
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen py-2">
      <main className="flex flex-col items-center justify-center w-full flex-1 px-20 text-center">
        <h1 className="text-4xl font-bold mb-6">Добавить тренировку</h1>
        <form onSubmit={handleSubmit} className="w-full max-w-xs">
          <Input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="mb-4"
          />
          <Input
            type="number"
            placeholder="Продолжительность (минуты)"
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
            className="mb-4"
          />
          <Textarea
            placeholder="Заметки"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="mb-4"
          />
          <Button type="submit" className="w-full">Добавить тренировку</Button>
        </form>
      </main>
    </div>
  );
}
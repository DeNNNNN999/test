"use client"

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { useToast } from "@/components/ui/use-toast"

interface User {
  username: string;
}

interface Workout {
  id: number;
  date: string;
  duration: number;
  notes: string;
}

export default function Dashboard() {
  const [user, setUser] = useState<User | null>(null);
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const router = useRouter();
  const { toast } = useToast()

  useEffect(() => {
    const fetchUserProfile = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        router.push('/login');
        return;
      }

      try {
        const response = await fetch('http://localhost:3001/api/profile', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (response.ok) {
          const userData = await response.json();
          setUser(userData);
        } else {
          throw new Error('Failed to fetch user profile');
        }
      } catch (error) {
        console.error('Error:', error);
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить профиль пользователя",
          variant: "destructive",
        })
        router.push('/login');
      }
    };

    const fetchWorkouts = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        return;
      }

      try {
        const response = await fetch('http://localhost:3001/api/workouts', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (response.ok) {
          const workoutsData = await response.json();
          setWorkouts(workoutsData);
        } else {
          throw new Error('Failed to fetch workouts');
        }
      } catch (error) {
        console.error('Error:', error);
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить тренировки",
          variant: "destructive",
        })
      }
    };

    fetchUserProfile();
    fetchWorkouts();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    router.push('/login');
  };

  if (!user) {
    return <div>Loading...</div>;
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen py-2">
      <main className="flex flex-col items-center justify-center w-full flex-1 px-20 text-center">
        <h1 className="text-4xl font-bold mb-6">Панель управления ТрекСпорт</h1>
        <p className="mb-4">Добро пожаловать, {user.username}!</p>
        <Link href="/workouts/add" passHref>
          <Button className="mb-4">Добавить тренировку</Button>
        </Link>
        <div className="w-full max-w-2xl">
          <h2 className="text-2xl font-bold mb-4">Последние тренировки</h2>
          {workouts.length > 0 ? (
            <ul>
              {workouts.map((workout) => (
                <li key={workout.id} className="mb-2">
                  <strong>{new Date(workout.date).toLocaleDateString()}</strong> - {workout.duration} минут
                  {workout.notes && <p className="text-sm">{workout.notes}</p>}
                </li>
              ))}
            </ul>
          ) : (
            <p>У вас пока нет записанных тренировок.</p>
          )}
        </div>
        <Button onClick={handleLogout} className="mt-8">Выйти</Button>
      </main>
    </div>
  );
}
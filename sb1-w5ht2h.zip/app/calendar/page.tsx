"use client"

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Calendar } from '@/components/ui/calendar';
import { Button } from '@/components/ui/button';
import { useToast } from "@/components/ui/use-toast"

interface Event {
  id: number;
  date: string;
  type: 'workout' | 'competition';
  name?: string;
}

export default function CalendarPage() {
  const [events, setEvents] = useState<Event[]>([]);
  const [date, setDate] = useState<Date | undefined>(new Date());
  const router = useRouter();
  const { toast } = useToast()

  useEffect(() => {
    const fetchEvents = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        router.push('/login');
        return;
      }

      try {
        const response = await fetch('http://localhost:3001/api/calendar', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });

        if (response.ok) {
          const eventsData = await response.json();
          setEvents(eventsData);
        } else {
          throw new Error('Failed to fetch events');
        }
      } catch (error) {
        console.error('Error:', error);
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить события",
          variant: "destructive",
        })
      }
    };

    fetchEvents();
  }, []);

  const handleDateChange = (newDate: Date | undefined) => {
    setDate(newDate);
  };

  const getEventsForDate = (date: Date) => {
    return events.filter(event => new Date(event.date).toDateString() === date.toDateString());
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen py-2">
      <main className="flex flex-col items-center justify-center w-full flex-1 px-20 text-center">
        <h1 className="text-4xl font-bold mb-6">Календарь</h1>
        <div className="flex space-x-8">
          <div>
            <Calendar
              mode="single"
              selected={date}
              onSelect={handleDateChange}
              className="rounded-md border"
            />
          </div>
          <div className="w-64">
            <h2 className="text-2xl font-bold mb-4">События на {date?.toLocaleDateString()}</h2>
            {date && getEventsForDate(date).length > 0 ? (
              <ul>
                {getEventsForDate(date).map((event) => (
                  <li key={event.id} className="mb-2">
                    <strong>{event.type === 'competition' ? event.name : 'Тренировка'}</strong>
                    <span> - {event.type === 'competition' ? 'Соревнование' : 'Тренировка'}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p>Нет событий на выбранную дату.</p>
            )}
          </div>
        </div>
        <div className="mt-8 space-x-4">
          <Button onClick={() => router.push('/workouts/add')}>Добавить тренировку</Button>
          <Button onClick={() => router.push('/competitions/add')}>Добавить соревнование</Button>
        </div>
      </main>
    </div>
  );
}
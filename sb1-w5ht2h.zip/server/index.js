const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');

const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());

const pool = new Pool({
  user: 'your_username',
  host: 'localhost',
  database: 'treksport',
  password: 'your_password',
  port: 5432,
});

const SECRET_KEY = 'your_secret_key';

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (token == null) return res.sendStatus(401);

  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

app.post('/api/register', async (req, res) => {
  const { username, email, password } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const result = await pool.query(
      'INSERT INTO users (username, email, password) VALUES ($1, $2, $3) RETURNING id',
      [username, email, hashedPassword]
    );
    res.status(201).json({ message: 'User registered successfully', userId: result.rows[0].id });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error registering user' });
  }
});

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (result.rows.length > 0) {
      const user = result.rows[0];
      if (await bcrypt.compare(password, user.password)) {
        const token = jwt.sign({ userId: user.id }, SECRET_KEY);
        res.json({ token });
      } else {
        res.status(400).json({ message: 'Invalid credentials' });
      }
    } else {
      res.status(400).json({ message: 'User not found' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error logging in' });
  }
});

app.get('/api/profile', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT id, username, email FROM users WHERE id = $1', [req.user.userId]);
    if (result.rows.length > 0) {
      res.json(result.rows[0]);
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching user profile' });
  }
});

// Workouts routes
app.post('/api/workouts', authenticateToken, async (req, res) => {
  const { date, duration, notes } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO workouts (user_id, date, duration, notes) VALUES ($1, $2, $3, $4) RETURNING id',
      [req.user.userId, date, duration, notes]
    );
    res.status(201).json({ message: 'Workout added successfully', workoutId: result.rows[0].id });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error adding workout' });
  }
});

app.get('/api/workouts', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM workouts WHERE user_id = $1 ORDER BY date DESC',
      [req.user.userId]
    );
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching workouts' });
  }
});

// Competitions routes
app.post('/api/competitions', authenticateToken, async (req, res) => {
  const { name, date, location, description } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO competitions (user_id, name, date, location, description) VALUES ($1, $2, $3, $4, $5) RETURNING id',
      [req.user.userId, name, date, location, description]
    );
    res.status(201).json({ message: 'Competition added successfully', competitionId: result.rows[0].id });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error adding competition' });
  }
});

app.get('/api/competitions', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM competitions WHERE user_id = $1 ORDER BY date DESC',
      [req.user.userId]
    );
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching competitions' });
  }
});

// Calendar events route
app.get('/api/calendar', authenticateToken, async (req, res) => {
  try {
    const workoutsResult = await pool.query(
      'SELECT id, date, \'workout\' as type FROM workouts WHERE user_id = $1',
      [req.user.userId]
    );
    const competitionsResult = await pool.query(
      'SELECT id, date, \'competition\' as type, name FROM competitions WHERE user_id = $1',
      [req.user.userId]
    );
    const events = [...workoutsResult.rows, ...competitionsResult.rows];
    res.json(events);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching calendar events' });
  }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});